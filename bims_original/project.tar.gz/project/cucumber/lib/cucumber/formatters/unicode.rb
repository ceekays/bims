# This is for backwards compatibility
require 'cucumber/formatter/unicode'
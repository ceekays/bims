= Cucumber

The main website is at http://cukes.info/
The documentation is at http://github.com/aslakhellesoy/cucumber/wikis/home/

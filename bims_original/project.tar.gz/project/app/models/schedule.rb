class Schedule < ActiveRecord::Base
end

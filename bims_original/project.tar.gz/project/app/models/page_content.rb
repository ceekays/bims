class PageContent < ActiveRecord::Base
end

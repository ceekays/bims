#Commented by Edmond Kachale on April 27, 2009 
#Reason: this 'require' statement does not work. The statement that follows replaces it
#require 'test_helper'

require File.dirname(__FILE__) + '/../test_helper'

class UserLogTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
